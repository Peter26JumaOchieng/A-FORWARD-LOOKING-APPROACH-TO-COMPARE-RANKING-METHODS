# MasseyColleySpearman
Quick analysis of Massey and Colley rankings of 2014 college basketball teams for EdX DavidsonX: D003x.2 Applications of Linear Algebra (Part 2)
