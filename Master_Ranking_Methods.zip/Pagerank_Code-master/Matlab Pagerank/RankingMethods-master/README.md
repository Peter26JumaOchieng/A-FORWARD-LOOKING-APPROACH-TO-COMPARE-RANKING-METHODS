# RankingMethods
MATLAB code of, Plurality, Borda Count, Colley's Method, Massey's Method, and Page Rank used to determine the winner in a multi-candidate election
